# McOS-Mint-Cinnamon-Edition
A specially design version of McOS for the Linux Mint Cinnamon 19
