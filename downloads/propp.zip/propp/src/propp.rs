use std::fs;
use std::path::PathBuf;
use anyhow::{Context, Result};

pub struct ProPP {
    title: String,
    classname: String,
    filename: String,
    dir: PathBuf,
}

impl ProPP {
    pub fn new(args: &[String]) -> Result<Self> {
        let title = &args[1];
        let mut classname = title.clone();
        let mut filename = Self::str_to_lower(title);

        if Self::has_space(title) {
            Self::change_space(&mut classname, "");
            Self::change_space(&mut filename, "-");
        }

        let dir = PathBuf::from(&classname);

        if dir.exists() {
            eprintln!("Error. Project/Directory already exists.");
            std::process::exit(65);
        }

        fs::create_dir(&dir).context("Failed to create directory")?;

        Ok(Self {
            title: title.clone(),
            classname,
            filename,
            dir,
        })
    }

    pub fn run(&self) -> Result<()> {
        let path_header = self.dir.join(format!("{}.hpp", self.filename));
        let path_cpp = self.dir.join(format!("{}.cpp", self.filename));
        let path_main = self.dir.join("main.cpp");
        let path_build = self.dir.join("build.ter");

        let header_file = self.set_header_file();
        let cpp_file = self.set_cpp_file();
        let main_file = self.set_main_file();
        let build_file = self.set_build_file();

        fs::write(&path_header, header_file).context("Failed to write header file")?;
        fs::write(&path_cpp, cpp_file).context("Failed to write cpp file")?;
        fs::write(&path_main, main_file).context("Failed to write main file")?;
        fs::write(&path_build, build_file).context("Failed to write build file")?;

        Ok(())
    }

    fn str_to_lower(s: &str) -> String {
        s.to_lowercase()
    }

    fn has_space(s: &str) -> bool {
        s.contains(' ')
    }

    fn change_space(s: &mut String, replacement: &str) {
        *s = s.replace(' ', replacement);
    }

    fn set_header_file(&self) -> String {
        format!(
            "#pragma once\n\n\
            #include <SFML/Graphics.hpp>\n\
            #include <memory>\n\n\
            class {} {{\n\
              sf::RenderWindow window;\n\
              void events(), draw();\n\n\
              public:\n\
                {}();\n\
                void run();\n\
            }};\n",
            self.classname, self.classname
        )
    }

    fn set_cpp_file(&self) -> String {
        format!(
            "#include \"{}.hpp\"\n\n\
            {}::{}() : window(\n\
                sf::VideoMode(1280,720),\n\
                \"SFML {}\",\n\
                sf::Style::Titlebar | sf::Style::Close) {{\n\
            }}\n\n\
            void {}::events() {{\n\
              auto event = std::make_unique<sf::Event>();\n\
              while(window.pollEvent(*event)) {{\n\
                if(event->type == sf::Event::Closed) {{\n\
                  window.close();\n\
                }}\n\
              }}\n\
            }}\n\n\
            void {}::draw() {{\n\
              window.clear();\n\
              window.display();\n\
            }}\n\n\
            void {}::run() {{\n\
              while(window.isOpen()) {{\n\
                events();\n\
                draw();\n\
              }}\n\
            }}",
            self.filename,
            self.classname,
            self.classname,
            self.title,
            self.classname,
            self.classname,
            self.classname
        )
    }

    fn set_main_file(&self) -> String {
        format!(
            "#include \"{}.hpp\"\n\n\
            int main() {{\n\
              auto obj = std::make_unique<{}>();\n\
              obj->run();\n\
              return EXIT_SUCCESS;\n\
            }}\n",
            self.filename, self.classname
        )
    }

    fn set_build_file(&self) -> String {
        "auto flags = \"-g -Wall -Werror -Wpedantic -fsanitize=address\"\n\
         flags = \"-Ofast\"\n\n\
         auto build = \"g++ \" + flags + \" *.cpp -lsfml-graphics -lsfml-window -lsfml-system\"\n\
         output(build)\n\n\
         exec(build)\n\
         exec(\"./a.out 2>/dev/null\")\n"
            .to_string()
    }
}
