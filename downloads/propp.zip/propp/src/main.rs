mod propp;

use anyhow::Result;
use std::env;

fn main() -> Result<()> {
    let args: Vec<String> = env::args().collect();

    if args.len() <= 1 {
        eprintln!("Enter the class name.");
        std::process::exit(1);
    }

    let pro = propp::ProPP::new(&args)?;
    pro.run()?;

    Ok(())
}
