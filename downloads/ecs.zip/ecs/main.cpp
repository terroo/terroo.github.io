#include <SFML/Graphics.hpp>
#include <vector>
#include "ecs/EntityManager.hpp"
#include "components/PositionComponent.hpp"
#include "components/SpriteComponent.hpp"
#include "systems/MapSystem.hpp"
#include "systems/RenderSystem.hpp"
#include "systems/MovementSystem.hpp"
#include <iostream>

int main() {
  sf::RenderWindow window(sf::VideoMode(1280, 720), "ECS Map");

  EntityManager em;
  MapSystem mapSystem;
  RenderSystem renderSystem;
  MovementSystem movementSystem;

  std::vector<Entity> tileEntities;

  if (!mapSystem.load(em, "./assets/map.tmx", tileEntities)) {
    std::cerr << "Erro ao carregar mapa.\n";
    return -1;
  }

  Entity player = em.createEntity();
  em.addComponent(player, PositionComponent{ 10.f, 512.f });

  sf::RectangleShape playerShape(sf::Vector2f(64.f, 64.f));
  playerShape.setFillColor(sf::Color::Red);

  float player_speed = 300.f;
  sf::Clock clock;

  while (window.isOpen()) {
    sf::Event e;
    while (window.pollEvent(e)) {
      if (e.type == sf::Event::Closed) window.close();
    }

    float dt = clock.restart().asSeconds();
    auto& playerPos = em.getComponent<PositionComponent>(player);
    movementSystem.update(playerPos, dt, player_speed, mapSystem.getMapWidth(), playerShape.getSize().x);

    float offsetX = playerPos.x + playerShape.getSize().x / 2.f - window.getSize().x / 2.f;
    if (offsetX < 0.f) offsetX = 0.f;
    if (offsetX > mapSystem.getMapWidth() - window.getSize().x)
      offsetX = mapSystem.getMapWidth() - window.getSize().x;

    playerShape.setPosition(playerPos.x - offsetX, playerPos.y);

    window.clear(sf::Color(138, 138, 138));
    renderSystem.render(window, em, tileEntities, offsetX);
    window.draw(playerShape);
    window.display();
  }

  return 0;
}

