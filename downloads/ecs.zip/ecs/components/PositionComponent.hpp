// components/PositionComponent.hpp
#pragma once
struct PositionComponent {
    float x, y;
};

