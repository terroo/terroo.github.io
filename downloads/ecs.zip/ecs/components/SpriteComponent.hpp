// components/SpriteComponent.hpp
#pragma once
#include <SFML/Graphics.hpp>

struct SpriteComponent {
    sf::Sprite sprite;
};

