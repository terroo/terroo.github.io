// ecs/EntityManager.hpp
#pragma once
#include "Entity.hpp"
#include "Component.hpp"
#include <unordered_map>
#include <typeindex>
#include <memory>

class EntityManager {
    Entity nextEntity = 0;
    std::unordered_map<std::type_index, std::shared_ptr<void>> componentArrays;

public:
    Entity createEntity() { return nextEntity++; }

    template<typename T>
    void addComponent(Entity e, const T& component) {
        getComponentArray<T>()->insert(e, component);
    }

    template<typename T>
    T& getComponent(Entity e) {
        return getComponentArray<T>()->get(e);
    }

    template<typename T>
    bool hasComponent(Entity e) {
        return getComponentArray<T>()->has(e);
    }

private:
    template<typename T>
    std::shared_ptr<ComponentArray<T>> getComponentArray() {
        auto type = std::type_index(typeid(T));
        if (componentArrays.find(type) == componentArrays.end()) {
            componentArrays[type] = std::make_shared<ComponentArray<T>>();
        }
        return std::static_pointer_cast<ComponentArray<T>>(componentArrays[type]);
    }
};

