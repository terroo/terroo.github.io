// ecs/Component.hpp
#pragma once
#include <unordered_map>

template<typename T>
class ComponentArray {
public:
    std::unordered_map<Entity, T> components;

    void insert(Entity entity, const T& component) {
        components[entity] = component;
    }

    T& get(Entity entity) {
        return components.at(entity);
    }

    bool has(Entity entity) {
        return components.find(entity) != components.end();
    }
};

