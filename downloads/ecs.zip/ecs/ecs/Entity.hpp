// ecs/Entity.hpp
#pragma once
#include <cstdint>

using Entity = std::uint32_t;
const Entity MAX_ENTITIES = 5000;

