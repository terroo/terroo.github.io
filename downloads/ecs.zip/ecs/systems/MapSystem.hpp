// systems/MapSystem.hpp
#pragma once
#include <tmxlite/Map.hpp>
#include <tmxlite/TileLayer.hpp>
#include <SFML/Graphics.hpp>
#include "../ecs/EntityManager.hpp"
#include "../components/PositionComponent.hpp"
#include "../components/SpriteComponent.hpp"

class MapSystem {
  sf::Texture floor_tex, box_tex;
  float map_width = 0, map_height = 0;

  public:
  bool load(EntityManager& em, const std::string& path, std::vector<Entity>& tileEntities) {
    tmx::Map map;
    if (!map.load(path)) return false;

    floor_tex.loadFromFile("./assets/floor.jpg");
    box_tex.loadFromFile("./assets/box.jpg");

    auto tile_size = map.getTileSize();
    const auto& layers = map.getLayers();

    for (const auto& layer : layers) {
      if (layer->getType() != tmx::Layer::Type::Tile) continue;

      auto* tileLayer = dynamic_cast<const tmx::TileLayer*>(layer.get());
      const auto& tiles = tileLayer->getTiles();
      const auto size = tileLayer->getSize();

      for (std::size_t y = 0; y < size.y; ++y) {
        for (std::size_t x = 0; x < size.x; ++x) {
          std::size_t index = x + y * size.x;
          std::uint32_t id = tiles[index].ID;
          if (id == 0) continue;

          Entity tile = em.createEntity();
          tileEntities.push_back(tile);

          em.addComponent(tile, PositionComponent{ float(x * tile_size.x), float(y * tile_size.y) });

          sf::Sprite sprite;
          sprite.setTexture((id == 1) ? box_tex : floor_tex);
          em.addComponent(tile, SpriteComponent{ sprite });
        }
      }
    }

    map_width = static_cast<float>(map.getTileCount().x * tile_size.x);
    map_height = static_cast<float>(map.getTileCount().y * tile_size.y);
    return true;
  }

  float getMapWidth() const { return map_width; }
  float getMapHeight() const { return map_height; }
};

