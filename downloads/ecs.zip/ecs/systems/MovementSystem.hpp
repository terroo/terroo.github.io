// systems/MovementSystem.hpp
#pragma once
#include <SFML/Window.hpp>
#include "../components/PositionComponent.hpp"

class MovementSystem {
public:
    void update(PositionComponent& pos, float dt, float speed, float map_width, float entity_width) {
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Right)) pos.x += speed * dt;
        else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left)) pos.x -= speed * dt;

        if (pos.x < 0.f) pos.x = 0.f;
        if (pos.x > map_width - entity_width) pos.x = map_width - entity_width;
    }
};

