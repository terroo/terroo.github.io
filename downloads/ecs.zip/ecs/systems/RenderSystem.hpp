// systems/RenderSystem.hpp
#pragma once
#include <SFML/Graphics.hpp>
#include "../ecs/EntityManager.hpp"
#include "../components/PositionComponent.hpp"
#include "../components/SpriteComponent.hpp"

class RenderSystem {
public:
    void render(sf::RenderWindow& window, EntityManager& em, const std::vector<Entity>& entities, float offsetX = 0.f) {
        for (auto entity : entities) {
            if (!em.hasComponent<PositionComponent>(entity) || !em.hasComponent<SpriteComponent>(entity)) continue;

            auto& pos = em.getComponent<PositionComponent>(entity);
            auto& sprite = em.getComponent<SpriteComponent>(entity).sprite;
            sprite.setPosition(pos.x - offsetX, pos.y);
            window.draw(sprite);
        }
    }
};

