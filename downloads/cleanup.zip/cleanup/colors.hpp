#ifndef COLORS_H
#define COLORS_H
#include <iostream>

namespace hey {

  const std::string gray = "\033[30;10m", // normal
        grayn = "\033[30;1m", // bold
        grayf = "\033[30;2m", // weak
        grayi = "\033[30;3m", // italics
        grays = "\033[30;4m", // underline
        grayp = "\033[30;5m", // blinking
        grayb = "\033[30;7m", // background
        grayc = "\033[30;9m", // canceled

        red = "\033[31;10m", // normal
        redn = "\033[31;1m", // bold
        redf = "\033[31;2m", // weak
        redi = "\033[31;3m", // italics
        reds = "\033[31;4m", // underscore
        redp = "\033[31;5m", // flashing
        redb = "\033[31;7m", // background
        redc = "\033[31;9m", // canceled

        green = "\033[32;10m", // normal
        greenn = "\033[32;1m", // bold
        greenf = "\033[32;2m", // weak
        greeni = "\033[32;3m", // italics
        greens = "\033[32;4m", // underline
        greenp = "\033[32;5m", // blinking
        greenb = "\033[32;7m", // background
        greenc = "\033[32;9m", // canceled

        yellow = "\033[33;10m", // normal
        yellown = "\033[33;1m", // bold
        yellowf = "\033[33;2m", // weak
        yellowi = "\033[33;3m", // italics
        yellows = "\033[33;4m", // underlined
        yellowp = "\033[33;5m", // blinking
        yellowb = "\033[33;7m", // background
        yellowc = "\033[33;9m", // canceled

        blue = "\033[34;10m", // normal
        bluen = "\033[34;1m", // bold
        bluef = "\033[34;2m", // weak
        bluei = "\033[34;3m", // italics
        blues = "\033[34;4m", // underline
        bluep = "\033[34;5m", // blinking
        blueb = "\033[34;7m", // background
        bluec = "\033[34;9m", // canceled

        purple = "\033[35;10m", // normal
        purplen = "\033[35;1m", // bold
        purplef = "\033[35;2m", // weak
        purplei = "\033[35;3m", // italics
        purples = "\033[35;4m", // underline
        purplep = "\033[35;5m", // blinking
        purpleb = "\033[35;7m", // background
        purplec = "\033[35;9m", // canceled

        cyan = "\033[36;10m", // normal
        cyann = "\033[36;1m", // bold
        cyanf = "\033[36;2m", // weak
        cyani = "\033[36;3m", // italics
        cyans = "\033[36;4m", // underscore
        cyanp = "\033[36;5m", // blinking
        cyanb = "\033[36;7m", // background
        cyanc = "\033[36;9m", // canceled

        white = "\033[38;10m", // normal
        whiten = "\033[38;1m", // bold
        whitef = "\033[38;2m", // weak
        whitei = "\033[38;3m", // italics
        whites = "\033[38;4m", // underscore
        whitep = "\033[38;5m", // blinking
        whiteb = "\033[38;7m", // background
        whitec = "\033[38;9m", // canceled

        off = "\033[m"; // turns off
}

#endif
