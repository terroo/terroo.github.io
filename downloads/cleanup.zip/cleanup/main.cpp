#include "cleanup.hpp"

int main(int argc, char** argv){
    bool debug {false};
    if(argc > 1){
        std::string param = argv[1];
        if(param == "--debug"){
            debug = true;
        }else{
            std::cerr << "Use: " << argv[0] << " [--debug]\n";
            return EXIT_FAILURE;
        }
    }
    auto lp = std::make_unique<Cleanup>(debug);
    lp->run();
    return EXIT_SUCCESS;
}
